package yumin;

public class submit03 {

    public static void main(String[] args) {


        int c = 1;
        for (int i = 1; i < 10; i++) {
            c *= i;

            System.out.println(c);
        }

        String findWally = "윌리울리일리울리울리일리월리일리윌리월리울리일리일리월리일리윌리일리윌리일리월리월리윌리울리윌리울리일리울리울리윌리일리";
        int w = 0;
        for (int i = 0; i < findWally.length(); i += 2) {
            String subStr = (findWally.substring(i, i + 2));

            if (subStr.equals("월리")) {

                w += 1;

            }
        }
        System.out.println(w);
        String stars = "*****";

         stars.substring(0, 5); // 어 ?? 0, 5 두번 째 1, 5
        stars.substring(1, 5); //
        stars.substring(2, 5); //
        stars.substring(3, 5);
        stars.substring(4, 5);
        stars.substring(5, 5);

        String C = "";
        for (int i = 0; i < stars.length(); i++) {

             C = stars.substring(i, stars.length());

            System.out.println(C);
        }


    }


}