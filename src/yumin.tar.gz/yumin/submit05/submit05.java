package yumin.submit05;

public class submit05 {
    public static void main(String[] args) {

        System.out.println(3 % 3);

        makeTree(5);
        makeTree(7);

        System.out.println("\n==============================\n"); // 1번끝

        String example = "로꾸꺼 로꾸꺼";
        String result = reverseStr(example);
        System.out.println(result);

        System.out.println("\n=============================\n");

        String myBinaryStr = makeBinary(23);
        System.out.println(myBinaryStr);


    }// 메소드끝

    public static String makeBinary(int n){

        // 문자열 변수를 하나 선언해서
        String empty = "";

        // 입력받은 정수를 2로 나눈 나머지를 문자열 변수에 더한다.
        //empty += n % 2;  -> 23 % 2 = 1
        //         11 % 2;  ->11 % 2 = 1
        //         5  % 2;  -> 5 % 2 = 1
        //                     2 % 2 = 0
        //                     1 % 2 = 1

        while(n >= 1){
            empty += n%2;
            n=n/2;

        }

        // 이진수로 만들어진 문자열 변수를 거꾸로(로꾸꺼) 뒤집은 다음 리턴
        String reverse1 = "";
        for (int i = 0; i < empty.length(); i++){
            reverse1 += empty.substring((empty.length()-1-i),empty.length()-i);

        }




        return reverse1 ;
    }



    public static String reverseStr(String example) {
        String reverse = "";


        for (int i = 0; i <= example.length() - 1; i++) {
            reverse += example.substring((example.length() - 1) - i, (example.length()) - i);


        }
        return reverse;
    }

    public static void makeTree(int n) {
        for (int i = 0; i < n; i++) {

            String blank = " ";
            for (int k = 0; k < (n - 1) - i; k++) {
                blank += " ";
            }
            String stars = " ";
            for (int k = 0; k < (i * 2) + 1; k++) {
                stars += "*";
            }
            System.out.println(blank + stars);

        }

    }
}
